﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace questionstest
{
    public partial class Form1 : Form
    {
        int correctAnswer;
        int questionNumber = 1;
        int score;
        int percentage;
        int totalQuestions;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            askQuestion(questionNumber);
            totalQuestions = 8;
        }
        private void askQuestion(int qnum)
        {

            switch (qnum)
            {
                case 1:  
                    label1.Text = "Which of the following gives the correct count of the constructors that a class can define?";
                    button1.Text = "1";
                    button2.Text = "2";
                    button3.Text = "Any number";
                    button4.Text = "5";
                    button5.Text = "None of the above";

                    correctAnswer = 3;
                    break;
                case 2:
                    label1.Text = "What is the correct name of a method which has the same name as that of class and used to destroy objects?";
                    button1.Text = "Constructor";
                    button2.Text = "Finalize()";
                    button3.Text = "End";
                    button4.Text = "Destructor";
                    button5.Text = "Correct all";

                    correctAnswer = 4;
                    break;
                case 3:                
                    label1.Text = "Which of the following is a reference type in C#?";
                    button1.Text = "String";
                    button2.Text = "Long";
                    button3.Text = "Boolean";
                    button4.Text = "None of the above";
                    button5.Text = "Int";

                    correctAnswer = 1;
                    break;
                case 4:         
                    label1.Text = "Struct is a_________?";
                    button1.Text = "Reference type";
                    button2.Text = "Value type";
                    button3.Text = "Class type";
                    button4.Text = "String type";
                    button5.Text = "Decimal type";

                    correctAnswer = 2;
                    break;
                case 5:                 
                    label1.Text = "Which of the following datatype can be used with enum?";
                    button1.Text = "int";
                    button2.Text = "string";
                    button3.Text = "boolean";
                    button4.Text = "All of the above";
                    button5.Text = "char";

                    correctAnswer = 1;
                    break;
                case 6:                
                    label1.Text = "String is ___________";
                    button1.Text = "Mutable";
                    button2.Text = "Immutable";
                    button3.Text = "Static";
                    button4.Text = "Value type";
                    button5.Text = "All of the above";

                    correctAnswer = 2;
                    break;
                case 7:                  
                    label1.Text = "All arrays start with _____ index.";
                    button1.Text = "1";
                    button2.Text = "0";
                    button3.Text = "-1";
                    button4.Text = "2";
                    button5.Text = "0.0";

                    correctAnswer = 2;
                    break;
                case 8:
                    label1.Text = "Return type of Predicate<T>() is always a _____.";
                    button1.Text = "int";
                    button2.Text = "string";
                    button3.Text = "boolean";
                    button4.Text = "void";
                    button5.Text = "char";

                    correctAnswer = 3;
                    break;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            var senderObject = (Button)sender;

            int buttonTag = Convert.ToInt32(senderObject.Tag);

            if (buttonTag == correctAnswer)
            {
                score++;
            }

            if (questionNumber == totalQuestions)
            {
                // work out the percentage

                percentage = (int)Math.Round((float)(score * 8) / totalQuestions);

                MessageBox.Show(
                    "Test Ended!" + Environment.NewLine +
                    "Your total score is " + score + Environment.NewLine +
                    "Click OK to try again"
                    );

                score = 0;
                questionNumber = 0;
                askQuestion(questionNumber);

            }

            questionNumber++;
            askQuestion(questionNumber);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            var senderObject = (Button)sender;

            int buttonTag = Convert.ToInt32(senderObject.Tag);

            if (buttonTag == correctAnswer)
            {
                score++;
            }

            if (questionNumber == totalQuestions)
            {
                // work out the percentage

                percentage = (int)Math.Round((double)(score * 8) / totalQuestions);

                MessageBox.Show(
                    "Test Ended!" + Environment.NewLine +
                    "Your total score is " + score + Environment.NewLine +
                    "Click OK to try again"
                    );

                score = 0;
                questionNumber = 0;
                askQuestion(questionNumber);

            }

            questionNumber++;
            askQuestion(questionNumber);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            var senderObject = (Button)sender;

            int buttonTag = Convert.ToInt32(senderObject.Tag);

            if (buttonTag == correctAnswer)
            {
                score++;
            }

            if (questionNumber == totalQuestions)
            {
                // work out the percentage

                percentage = (int)Math.Round((double)(score * 8) / totalQuestions);

                MessageBox.Show(
                    "Test Ended!" + Environment.NewLine +
                    "Your total score is " + score + Environment.NewLine +
                    "Click OK to try again"
                    );

                score = 0;
                questionNumber = 0;
                askQuestion(questionNumber);

            }

            questionNumber++;
            askQuestion(questionNumber);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            var senderObject = (Button)sender;

            int buttonTag = Convert.ToInt32(senderObject.Tag);

            if (buttonTag == correctAnswer)
            {
                score++;
            }

            if (questionNumber == totalQuestions)
            {
                // work out the percentage

                percentage = (int)Math.Round((double)(score * 8) / totalQuestions);

                MessageBox.Show(
                    "Test Ended!" + Environment.NewLine +
                    "Your total score is " + score + Environment.NewLine +
                    "Click OK to try again"
                    );

                score = 0;
                questionNumber = 0;
                askQuestion(questionNumber);

            }

            questionNumber++;
            askQuestion(questionNumber);
        }

        private void button5_Click(object sender, EventArgs e)
        {
            var senderObject = (Button)sender;

            int buttonTag = Convert.ToInt32(senderObject.Tag);

            if (buttonTag == correctAnswer)
            {
                score++;
            }

            if (questionNumber == totalQuestions)
            {
                // work out the percentage

                percentage = (int)Math.Round((double)(score * 8) / totalQuestions);

                MessageBox.Show(
                    "Test Ended!" + Environment.NewLine +
                    "Your total score is " + score + Environment.NewLine +
                    "Click OK to try again"
                    );

                score = 0;
                questionNumber = 0;
                askQuestion(questionNumber);

            }

            questionNumber++;
            askQuestion(questionNumber);
        }
    }
}
